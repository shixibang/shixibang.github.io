//  Copyright © 2020 The nef Authors.

import CLIKit

// #: - MAIN <launcher>
CommandLineTool<JekyllCommand>.main()
