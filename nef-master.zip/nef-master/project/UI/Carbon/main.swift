//  Copyright © 2020 The nef Authors.

import CLIKit
import NefCarbon

// #: - MAIN <launcher - AppKit>
CommandLineTool<CarbonCommand>.main()
