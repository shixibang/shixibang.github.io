//  Copyright © 2019 The nef Authors.

#import <Foundation/Foundation.h>

//! Project version number for CLI.
FOUNDATION_EXPORT double CLIVersionNumber;

//! Project version string for CLI.
FOUNDATION_EXPORT const unsigned char CLIVersionString[];
