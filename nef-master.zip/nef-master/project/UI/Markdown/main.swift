//  Copyright © 2019 The nef Authors.

import CLIKit

// #: - MAIN <launcher>
CommandLineTool<MarkdownCommand>.main()
