//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>

//! Project version number for NefMarkdown.
FOUNDATION_EXPORT double NefMarkdownVersionNumber;

//! Project version string for NefMarkdown.
FOUNDATION_EXPORT const unsigned char NefMarkdownVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NefMarkdown/PublicHeader.h>
