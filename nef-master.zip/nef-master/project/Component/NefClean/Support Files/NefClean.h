//  Copyright © 2020 The nef Authors.

#import <Foundation/Foundation.h>

//! Project version number for NefClean.
FOUNDATION_EXPORT double NefCleanVersionNumber;

//! Project version string for NefClean.
FOUNDATION_EXPORT const unsigned char NefCleanVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NefClean/PublicHeader.h>


