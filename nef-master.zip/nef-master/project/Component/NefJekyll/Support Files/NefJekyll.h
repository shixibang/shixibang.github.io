//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>

//! Project version number for NefJekyll.
FOUNDATION_EXPORT double NefJekyllVersionNumber;

//! Project version string for NefJekyll.
FOUNDATION_EXPORT const unsigned char NefJekyllVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NefJekyll/PublicHeader.h>
