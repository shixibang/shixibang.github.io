//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>

//! Project version number for NefCarbon.
FOUNDATION_EXPORT double NefCarbonVersionNumber;

//! Project version string for NefCarbon.
FOUNDATION_EXPORT const unsigned char NefCarbonVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NefCarbon/PublicHeader.h>
