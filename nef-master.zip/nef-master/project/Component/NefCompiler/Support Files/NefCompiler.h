//  Copyright © 2020 The nef Authors.

#import <Foundation/Foundation.h>

//! Project version number for NefCompiler.
FOUNDATION_EXPORT double NefCompilerVersionNumber;

//! Project version string for NefCompiler.
FOUNDATION_EXPORT const unsigned char NefCompilerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NefCompiler/PublicHeader.h>


