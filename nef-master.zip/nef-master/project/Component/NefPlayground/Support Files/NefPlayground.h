//  Copyright © 2020 The nef Authors.

#import <Foundation/Foundation.h>

//! Project version number for NefPlayground.
FOUNDATION_EXPORT double NefPlaygroundVersionNumber;

//! Project version string for NefPlayground.
FOUNDATION_EXPORT const unsigned char NefPlaygroundVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NefPlayground/PublicHeader.h>


