//  Copyright © 2019 The nef Authors.

#import <Foundation/Foundation.h>

//! Project version number for NefCommon.
FOUNDATION_EXPORT double NefCommonVersionNumber;

//! Project version string for NefCommon.
FOUNDATION_EXPORT const unsigned char NefCommonVersionString[];

