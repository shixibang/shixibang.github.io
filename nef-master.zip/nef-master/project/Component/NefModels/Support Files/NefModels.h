//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>

//! Project version number for NefModels.
FOUNDATION_EXPORT double NefModelsVersionNumber;

//! Project version string for NefModels.
FOUNDATION_EXPORT const unsigned char NefModelsVersionString[];
