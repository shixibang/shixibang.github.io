//  Copyright © 2019 The nef Authors.

import Foundation

enum AssetsBase64 {}
