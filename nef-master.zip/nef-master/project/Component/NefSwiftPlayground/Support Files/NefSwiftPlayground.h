//  Copyright © 2019 The nef Authors.

#import <Foundation/Foundation.h>

//! Project version number for NefSwiftPlayground.
FOUNDATION_EXPORT double NefSwiftPlaygroundVersionNumber;

//! Project version string for NefSwiftPlayground.
FOUNDATION_EXPORT const unsigned char NefSwiftPlaygroundVersionString[];
