//  Copyright © 2020 The nef Authors.

import Foundation

internal enum BuildConfiguration {
    static let buildVersion = "0.7.1"
    static let templateVersion = "0.7.1"
}
