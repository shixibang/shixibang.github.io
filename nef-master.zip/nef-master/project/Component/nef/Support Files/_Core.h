//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefCore.h"

FOUNDATION_EXPORT double CoreVersionNumber;
FOUNDATION_EXPORT const unsigned char CoreVersionString[];
