//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefClean.h"

FOUNDATION_EXPORT double CleanVersionNumber;
FOUNDATION_EXPORT const unsigned char CleanVersionString[];
