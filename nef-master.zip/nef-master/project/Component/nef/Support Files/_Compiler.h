//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefCompiler.h"

FOUNDATION_EXPORT double CompilerVersionNumber;
FOUNDATION_EXPORT const unsigned char CompilerVersionString[];
