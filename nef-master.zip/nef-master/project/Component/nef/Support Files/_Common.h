//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefCore.h"

//! Project version number for Markup.
FOUNDATION_EXPORT double NefCoreVersionNumber;

//! Project version string for Markup.
FOUNDATION_EXPORT const unsigned char NefCoreVersionString[];
