//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefSwiftPlayground.h"

FOUNDATION_EXPORT double SwiftPlaygroundAPIVersionNumber;
FOUNDATION_EXPORT const unsigned char SwiftPlaygroundAPIVersionString[];
