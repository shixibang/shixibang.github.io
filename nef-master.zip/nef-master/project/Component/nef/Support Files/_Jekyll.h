//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefJekyll.h"

FOUNDATION_EXPORT double JekyllVersionNumber;
FOUNDATION_EXPORT const unsigned char JekyllVersionString[];
