//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefCarbon.h"

FOUNDATION_EXPORT double CarbonVersionNumber;
FOUNDATION_EXPORT const unsigned char CarbonVersionString[];
