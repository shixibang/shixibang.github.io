//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefCommon.h"
#import "NefModels.h"

FOUNDATION_EXPORT double NefVersionNumber;
FOUNDATION_EXPORT const unsigned char NefVersionString[];
