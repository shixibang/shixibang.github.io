//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefPlayground.h"

FOUNDATION_EXPORT double PlaygroundVersionNumber;
FOUNDATION_EXPORT const unsigned char PlaygroundVersionString[];
