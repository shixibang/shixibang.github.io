//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>
#import "NefMarkdown.h"

FOUNDATION_EXPORT double MarkdownVersionNumber;
FOUNDATION_EXPORT const unsigned char MarkdownVersionString[];
