//  Copyright © 2020 The nef Authors.

#import <Foundation/Foundation.h>

//! Project version number for NefRender.
FOUNDATION_EXPORT double NefRenderVersionNumber;

//! Project version string for NefRender.
FOUNDATION_EXPORT const unsigned char NefRenderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NefRender/PublicHeader.h>


