//  Copyright © 2019 The nef Authors.

#import <Cocoa/Cocoa.h>

//! Project version number for NefCore.
FOUNDATION_EXPORT double NefCoreVersionNumber;

//! Project version string for NefCore.
FOUNDATION_EXPORT const unsigned char NefCoreVersionString[];
